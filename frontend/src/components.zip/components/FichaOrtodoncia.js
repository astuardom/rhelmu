import React, { useState, useEffect } from 'react';

const FichaOrtodoncia = ({ data = {}, onUpdate }) => {
  const [form, setForm] = useState({ maloclusion: '', planTratamiento: '', duracion: '', controles: [] });
  const [selectedControl, setSelectedControl] = useState(null);

  useEffect(() => {
    setForm({
      maloclusion: data.maloclusion || '',
      planTratamiento: data.planTratamiento || '',
      duracion: data.duracion || '',
      controles: data.controles || []
    });
  }, [data]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleAddControl = () => {
    const nuevaFecha = new Date().toLocaleDateString();
    setForm((prev) => ({
      ...prev,
      controles: [...prev.controles, { fecha: nuevaFecha, detalle: '' }]
    }));
  };

  const handleControlChange = (index, value) => {
    const updated = [...form.controles];
    updated[index].detalle = value;
    setForm((prev) => ({ ...prev, controles: updated }));
  };

  const handleDeleteControl = (index) => {
    const updated = [...form.controles];
    updated.splice(index, 1);
    setForm((prev) => ({ ...prev, controles: updated }));
    setSelectedControl(null);
  };

  const handleSave = () => {
    if (onUpdate) {
      onUpdate(form);
      alert('✅ Ficha ortodoncia guardada correctamente');
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow space-y-6">
      <h2 className="text-2xl font-bold">Ficha Ortodoncia</h2>

      <div className="grid grid-cols-1 gap-4">
        <div>
          <label className="block text-sm font-medium">Maloclusión</label>
          <input type="text" name="maloclusion" value={form.maloclusion} onChange={handleChange} className="w-full border rounded px-3 py-1" />
        </div>
        <div>
          <label className="block text-sm font-medium">Plan de Tratamiento</label>
          <input type="text" name="planTratamiento" value={form.planTratamiento} onChange={handleChange} className="w-full border rounded px-3 py-1" />
        </div>
        <div>
          <label className="block text-sm font-medium">Duración</label>
          <input type="text" name="duracion" value={form.duracion} onChange={handleChange} className="w-full border rounded px-3 py-1" />
        </div>
      </div>

      <div className="text-right">
        <button onClick={handleSave} className="bg-green-600 text-white px-5 py-2 rounded hover:bg-green-700">
          Guardar cambios
        </button>
      </div>
    </div>
  );
};

export default FichaOrtodoncia;
