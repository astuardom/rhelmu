import React, { useState, useRef } from 'react';

const BudgetEditor = ({ initialPatient = {}, onSaveBudget, onAddBudget }) => {
  const guardarPresupuesto = onSaveBudget || onAddBudget;
  
  // Estado para los datos del paciente (renombrado a localPatient)
  const [localPatient, setLocalPatient] = useState({
    nombre: initialPatient.nombre || '',
    rut: initialPatient.rut || '',
    email: initialPatient.email || '',
    telefono: initialPatient.telefono || '',
  });

  // Estado para el presupuesto
  const [budget, setBudget] = useState({
    id: Date.now(),
    fecha: new Date().toISOString().split('T')[0],
    items: [],
    descuento: 0,
    notas: '',
    estado: 'pendiente',
    confirmado: false
  });

  // Estado para nuevos items y control de guardado
  const [newItem, setNewItem] = useState({
    tratamiento: '',
    cantidad: 1,
    precio: 0,
    diente: ''
  });

  const [guardado, setGuardado] = useState(false);
  const budgetRef = useRef();

  // Manejadores de cambios
  const handleBudgetChange = (e) => {
    const { name, value } = e.target;
    setBudget(prev => ({ ...prev, [name]: value }));
  };

  const handlePatientChange = (e) => {
    const { name, value } = e.target;
    setLocalPatient(prev => ({ ...prev, [name]: value }));
  };

  const handleItemChange = (e) => {
    const { name, value } = e.target;
    setNewItem(prev => ({
      ...prev,
      [name]: name === 'cantidad' || name === 'precio' ? Number(value) : value
    }));
  };

  // Funciones para manejar items
  const addItem = () => {
    if (!newItem.tratamiento) {
      alert("Debe especificar un tratamiento");
      return;
    }
    if (newItem.precio <= 0) {
      alert("El precio debe ser mayor a cero");
      return;
    }

    const itemWithId = {
      ...newItem,
      id: Date.now(),
      subtotal: newItem.cantidad * newItem.precio
    };

    setBudget(prev => ({
      ...prev,
      items: [...prev.items, itemWithId]
    }));

    setNewItem({
      tratamiento: '',
      cantidad: 1,
      precio: 0,
      diente: ''
    });
  };

  const removeItem = (id) => {
    setBudget(prev => ({
      ...prev,
      items: prev.items.filter(item => item.id !== id)
    }));
  };

  // Cálculos de totales
  const calculateTotal = () => {
    const subtotal = budget.items.reduce((sum, item) => sum + item.subtotal, 0);
    const descuento = subtotal * (budget.descuento / 100);
    return {
      subtotal,
      descuento,
      total: subtotal - descuento
    };
  };

  // Función para imprimir
  const handlePrint = () => {
    try {
      if (!localPatient.nombre || budget.items.length === 0) {
        alert("Complete los datos del paciente y agregue tratamientos antes de imprimir");
        return;
      }

      const printWindow = window.open('', '_blank');
      if (!printWindow) {
        alert("No se pudo abrir la ventana de impresión. Por favor, desbloquee los popups.");
        return;
      }

      const opcionesFecha = { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
      };
      const fechaFormateada = new Date(budget.fecha).toLocaleDateString('es-ES', opcionesFecha);

      printWindow.document.write(`
        <html>
          <head>
            <title>Presupuesto Dental - ${localPatient.nombre}</title>
            <style>
              body { font-family: Arial, sans-serif; margin: 20px; }
              .header { text-align: center; margin-bottom: 20px; }
              .patient-info { margin-bottom: 20px; }
              table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
              th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
              th { background-color: #f2f2f2; }
              .totals { text-align: right; margin-top: 20px; }
              .notes { margin-top: 30px; }
            </style>
          </head>
          <body>
            <div class="header">
              <h2>Presupuesto Dental</h2>
              <p>Fecha: ${fechaFormateada}</p>
            </div>
            <div class="patient-info">
              <p><strong>Nombre:</strong> ${localPatient.nombre}</p>
              <p><strong>RUT:</strong> ${localPatient.rut || 'No especificado'}</p>
              <p><strong>Correo:</strong> ${localPatient.email || 'No especificado'}</p>
              <p><strong>Teléfono:</strong> ${localPatient.telefono || 'No especificado'}</p>
            </div>
            <table>
              <thead>
                <tr>
                  <th>Tratamiento</th>
                  <th>Diente</th>
                  <th>Cantidad</th>
                  <th>Precio Unitario</th>
                  <th>Subtotal</th>
                </tr>
              </thead>
              <tbody>
                ${budget.items.map(item => `
                  <tr>
                    <td>${item.tratamiento}</td>
                    <td>${item.diente || '-'}</td>
                    <td>${item.cantidad}</td>
                    <td>$${item.precio.toLocaleString('es-CL')}</td>
                    <td>$${item.subtotal.toLocaleString('es-CL')}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
            <div class="totals">
              <p><strong>Subtotal:</strong> $${calculateTotal().subtotal.toLocaleString('es-CL')}</p>
              ${budget.descuento > 0 ? `
                <p><strong>Descuento (${budget.descuento}%):</strong> -$${calculateTotal().descuento.toLocaleString('es-CL')}</p>
              ` : ''}
              <p><strong>Total:</strong> $${calculateTotal().total.toLocaleString('es-CL')}</p>
            </div>
            ${budget.notas ? `
              <div class="notes">
                <h3>Notas:</h3>
                <p>${budget.notas}</p>
              </div>
            ` : ''}
            <script>
              window.onload = function() {
                setTimeout(() => {
                  window.print();
                  window.close();
                }, 200);
              };
            </script>
          </body>
        </html>
      `);
      printWindow.document.close();
    } catch (error) {
      console.error("Error al generar el presupuesto:", error);
      alert("Ocurrió un error al generar el documento para imprimir");
    }
  };

  // Función para guardar
  const handleGuardar = () => {
    if (typeof guardarPresupuesto === 'function') {
      const fullBudget = {
        ...budget,
        paciente: localPatient
      };
      guardarPresupuesto(fullBudget);
      setGuardado(true);
    } else {
      console.error("No se proporcionó una función para guardar el presupuesto");
    }
  };

  // Función para confirmar
  const handleConfirmar = async () => {
    if (!guardado) {
      alert("Debe guardar el presupuesto antes de confirmar");
      return;
    }

    try {
      const res = await fetch("http://localhost:5000/api/pacientes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          nombre: localPatient.nombre,
          rut: localPatient.rut,
          telefono: localPatient.telefono,
          email: localPatient.email,
          odontograma: budget.items.map(i => i.diente).filter(d => d)
        })
      });

      if (res.ok) {
        alert("Presupuesto confirmado y paciente registrado.");
      } else {
        alert("Error al registrar paciente.");
      }
    } catch (error) {
      console.error("Error confirmando presupuesto:", error);
      alert("Ocurrió un error al confirmar el presupuesto");
    }
  };

  // Renderizado del componente
  return (
    <div className="bg-white rounded-xl shadow-sm p-6" ref={budgetRef}>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold">Presupuesto Dental</h2>
        <div className="flex space-x-3">
          <button
            onClick={handlePrint}
            className="px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg flex items-center"
          >
            🖨️ Imprimir
          </button>
          <button
            onClick={handleGuardar}
            className={`px-4 py-2 ${guardado ? 'bg-green-600' : 'bg-blue-600'} text-white rounded-lg`}
          >
            {guardado ? '✓ Guardado' : 'Guardar Presupuesto'}
          </button>
          <button
            onClick={handleConfirmar}
            className={`px-4 py-2 ${!guardado ? 'bg-gray-400' : 'bg-green-600'} text-white rounded-lg`}
            disabled={!guardado}
          >
            Confirmar Presupuesto
          </button>
        </div>
      </div>

      {/* Sección de datos del paciente */}
      <div className="mb-6 grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium mb-1">Nombre del Paciente*</label>
          <input
            type="text"
            name="nombre"
            value={localPatient.nombre}
            onChange={handlePatientChange}
            className="w-full px-3 py-2 border rounded-lg"
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">RUT</label>
          <input
            type="text"
            name="rut"
            value={localPatient.rut}
            onChange={handlePatientChange}
            className="w-full px-3 py-2 border rounded-lg"
            placeholder="12.345.678-9"
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Correo Electrónico</label>
          <input
            type="email"
            name="email"
            value={localPatient.email}
            onChange={handlePatientChange}
            className="w-full px-3 py-2 border rounded-lg"
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Teléfono</label>
          <input
            type="tel"
            name="telefono"
            value={localPatient.telefono}
            onChange={handlePatientChange}
            className="w-full px-3 py-2 border rounded-lg"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Fecha</label>
          <input
            type="date"
            name="fecha"
            value={budget.fecha}
            onChange={handleBudgetChange}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Descuento (%)</label>
          <input
            type="number"
            name="descuento"
            value={budget.descuento}
            onChange={handleBudgetChange}
            min="0"
            max="100"
            className="w-full px-3 py-2 border border-gray-300 rounded-lg"
          />
        </div>
      </div>

      <div className="mb-6">
        <h3 className="text-lg font-medium mb-3">Agregar Tratamiento</h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          <div>
            <label className="text-sm font-medium">Tratamiento*</label>
            <input
              type="text"
              name="tratamiento"
              value={newItem.tratamiento}
              onChange={handleItemChange}
              className="w-full px-3 py-2 border rounded-lg"
              placeholder="Ej: Limpieza"
              required
            />
          </div>
          <div>
            <label className="text-sm font-medium">Diente</label>
            <input
              type="text"
              name="diente"
              value={newItem.diente}
              onChange={handleItemChange}
              className="w-full px-3 py-2 border rounded-lg"
              placeholder="Ej: 11, 12"
            />
          </div>
          <div>
            <label className="text-sm font-medium">Cantidad*</label>
            <input
              type="number"
              name="cantidad"
              value={newItem.cantidad}
              onChange={handleItemChange}
              className="w-full px-3 py-2 border rounded-lg"
              min="1"
              required
            />
          </div>
          <div>
            <label className="text-sm font-medium">Precio*</label>
            <input
              type="number"
              name="precio"
              value={newItem.precio}
              onChange={handleItemChange}
              className="w-full px-3 py-2 border rounded-lg"
              min="0"
              required
            />
          </div>
        </div>
        <button
          onClick={addItem}
          className="mt-3 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
          disabled={!newItem.tratamiento || newItem.precio <= 0}
        >
          Agregar Tratamiento
        </button>
      </div>

      {budget.items.length > 0 && (
        <div className="mb-6">
          <h3 className="text-lg font-medium mb-3">Tratamientos</h3>
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs text-gray-500 uppercase">Tratamiento</th>
                <th className="px-6 py-3 text-left text-xs text-gray-500 uppercase">Diente</th>
                <th className="px-6 py-3 text-left text-xs text-gray-500 uppercase">Cantidad</th>
                <th className="px-6 py-3 text-left text-xs text-gray-500 uppercase">Precio</th>
                <th className="px-6 py-3 text-left text-xs text-gray-500 uppercase">Subtotal</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {budget.items.map(item => (
                <tr key={item.id}>
                  <td className="px-6 py-2">{item.tratamiento}</td>
                  <td className="px-6 py-2">{item.diente || '-'}</td>
                  <td className="px-6 py-2">{item.cantidad}</td>
                  <td className="px-6 py-2">${item.precio.toLocaleString('es-CL')}</td>
                  <td className="px-6 py-2">${item.subtotal.toLocaleString('es-CL')}</td>
                  <td className="px-6 py-2">
                    <button 
                      onClick={() => removeItem(item.id)} 
                      className="text-red-600 hover:underline"
                    >
                      Eliminar
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2">
          <label className="block text-sm font-medium mb-1">Notas</label>
          <textarea
            name="notas"
            value={budget.notas}
            onChange={handleBudgetChange}
            rows="4"
            className="w-full px-3 py-2 border rounded-lg"
            placeholder="Notas adicionales sobre el presupuesto..."
          />
        </div>
        <div className="bg-gray-50 p-4 rounded-lg">
          <h4 className="text-lg font-medium mb-3">Resumen</h4>
          <div className="space-y-2">
            <div className="flex justify-between">
              <span>Subtotal:</span>
              <span>${calculateTotal().subtotal.toLocaleString('es-CL')}</span>
            </div>
            {budget.descuento > 0 && (
              <div className="flex justify-between">
                <span>Descuento ({budget.descuento}%):</span>
                <span>-${calculateTotal().descuento.toLocaleString('es-CL')}</span>
              </div>
            )}
            <div className="flex justify-between font-semibold pt-2 border-t">
              <span>Total:</span>
              <span>${calculateTotal().total.toLocaleString('es-CL')}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BudgetEditor;