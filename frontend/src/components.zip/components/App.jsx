// 📁 src/App.jsx
import React, { useState, useEffect } from 'react';
import LayoutHeader from './components/LayoutHeader';
import PatientList from './components/PatientList';
import PatientDetailView from './components/PatientDetailView';
import CalendarView from './components/CalendarView';
import DashboardCard from './components/DashboardCard';
import WeeklyAppointments from './components/WeeklyAppointments';
import AssistantTools from './components/AssistantTools'; // NUEVO: WhatsApp, aseguradoras y recetas

const App = () => {
  const [currentView, setCurrentView] = useState('dashboard');
  const [pacientes, setPacientes] = useState([]);
  const [citas, setCitas] = useState([]);
  const [recetas, setRecetas] = useState([]);
  const [selectedPatient, setSelectedPatient] = useState(null);
  const rol = localStorage.getItem('rol');

  useEffect(() => {
    fetch("http://localhost:5000/api/pacientes")
      .then(res => res.json())
      .then(data => {
        setPacientes(data);
        if (data.length > 0) setSelectedPatient(data[0]);
      });
  }, []);

  useEffect(() => {
    fetch('http://localhost:5000/api/citas')
      .then(res => res.json())
      .then(data => setCitas(data));
  }, []);

  useEffect(() => {
    fetch('http://localhost:5000/api/recetas')
      .then(res => res.json())
      .then(data => setRecetas(data));
  }, []);

  return (
    <div className="min-h-screen bg-indigo-50">
      <LayoutHeader />
      <div className="max-w-7xl mx-auto px-4 py-6 grid grid-cols-12 gap-6">
        <div className="col-span-3">
          <div className="bg-white rounded-2xl shadow-md p-5 border border-indigo-100">
            <h2 className="font-bold mb-4 text-indigo-800 uppercase tracking-wide text-sm">Menú Principal</h2>
            <nav className="space-y-2 text-sm">
              <button onClick={() => setCurrentView('dashboard')}>📊 Dashboard</button>
              {(rol === 'admin' || rol === 'doctor' || rol === 'contador' || rol === 'asistente') && (
                <button onClick={() => setCurrentView('pacientes')}>🧑‍⚕️ Pacientes</button>
              )}
              {(rol === 'admin' || rol === 'doctor' || rol === 'contador' || rol === 'asistente') && (
                <button onClick={() => setCurrentView('calendario')}>📅 Calendario</button>
              )}
              {rol === 'asistente' && (
                <button onClick={() => setCurrentView('herramientas')}>🛠 Herramientas Asistente</button>
              )}
            </nav>
          </div>
        </div>

        <div className="col-span-9">
          {currentView === 'dashboard' && (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <DashboardCard title="Pacientes" value={pacientes.length} color="indigo" />
                <DashboardCard title="Citas" value={citas.length} color="green" />
                <DashboardCard title="Recetas" value={recetas.length} color="yellow" />
              </div>
              <WeeklyAppointments citas={citas} pacientes={pacientes} />
            </>
          )}

          {currentView === 'pacientes' && (
            <>
              <PatientList patients={pacientes} onSelectPatient={setSelectedPatient} />
              {selectedPatient && (
                <PatientDetailView
                  patient={selectedPatient}
                  mode={rol === 'asistente' ? 'readonly' : 'editable'}
                />
              )}
            </>
          )}

          {currentView === 'calendario' && (
            <CalendarView
              citas={citas}
              pacientes={pacientes}
              onAddAppointment={() => {}}
              onEditAppointment={() => {}}
              readOnly={rol === 'asistente'}
            />
          )}

          {currentView === 'herramientas' && rol === 'asistente' && (
            <AssistantTools paciente={selectedPatient} recetas={recetas} />
          )}
        </div>
      </div>
    </div>
  );
};

export default App;
