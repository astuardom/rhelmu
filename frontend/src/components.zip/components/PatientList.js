
import React, { useState } from 'react';

const PatientList = ({ patients, onSelectPatient }) => {
  const [currentPage, setCurrentPage] = useState(1);
  const patientsPerPage = 10;

  const totalPages = Math.ceil(patients.length / patientsPerPage);
  const startIndex = (currentPage - 1) * patientsPerPage;
  const currentPatients = patients.slice(startIndex, startIndex + patientsPerPage);

  return (
    <div className="bg-white rounded-lg shadow p-4">
      <h3 className="text-lg font-semibold mb-4">Listado de Pacientes</h3>
      <ul className="divide-y divide-gray-200">
        {currentPatients.map((patient) => (
          <li
            key={patient._id || patient.id}
            className="py-2 cursor-pointer hover:bg-blue-50 px-2 rounded"
            onClick={() => onSelectPatient(patient)}
          >
            <p className="text-sm font-medium text-gray-900">{patient.nombre}</p>
          </li>
        ))}
      </ul>

      <div className="flex justify-between items-center mt-4 text-sm">
        <button
          disabled={currentPage === 1}
          onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
          className={`px-3 py-1 rounded ${currentPage === 1 ? 'bg-gray-200 text-gray-400' : 'bg-blue-100 text-blue-600 hover:bg-blue-200'}`}
        >
          Anterior
        </button>
        <span>
          Página {currentPage} de {totalPages}
        </span>
        <button
          disabled={currentPage === totalPages}
          onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
          className={`px-3 py-1 rounded ${currentPage === totalPages ? 'bg-gray-200 text-gray-400' : 'bg-blue-100 text-blue-600 hover:bg-blue-200'}`}
        >
          Siguiente
        </button>
      </div>
    </div>
  );
};

export default PatientList;
