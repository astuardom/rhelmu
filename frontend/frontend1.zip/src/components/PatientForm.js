
import React, { useState, useEffect } from 'react';

const PatientForm = ({ onSave, onCancel, patient }) => {
  const [formData, setFormData] = useState({
    nombre: '',
    rut: '',
    edad: '',
    genero: '',
    telefono: '',
    email: ''
  });

  useEffect(() => {
    if (patient) {
      setFormData(patient);
    }
  }, [patient]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const url = patient?._id
      ? `http://localhost:5000/api/pacientes/${patient._id}`
      : "http://localhost:5000/api/pacientes";
    const method = patient?._id ? "PUT" : "POST";

    const res = await fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(formData)
    });

    const data = await res.json();
    onSave(data);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 bg-white p-6 rounded shadow">
      <h3 className="text-lg font-semibold">{patient ? 'Editar Paciente' : 'Nuevo Paciente'}</h3>
      <input name="nombre" value={formData.nombre} onChange={handleChange} placeholder="Nombre" className="w-full border p-2 rounded" required />
      <input name="rut" value={formData.rut} onChange={handleChange} placeholder="RUT" className="w-full border p-2 rounded" required />
      <input name="edad" type="number" value={formData.edad} onChange={handleChange} placeholder="Edad" className="w-full border p-2 rounded" required />
      <input name="genero" value={formData.genero} onChange={handleChange} placeholder="Género" className="w-full border p-2 rounded" />
      <input name="telefono" value={formData.telefono} onChange={handleChange} placeholder="Teléfono" className="w-full border p-2 rounded" />
      <input name="email" value={formData.email} onChange={handleChange} placeholder="Email" className="w-full border p-2 rounded" />
      <div className="flex justify-end space-x-2">
        <button type="button" onClick={onCancel} className="px-4 py-2 border rounded text-gray-600 hover:bg-gray-100">Cancelar</button>
        <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Guardar</button>
      </div>
    </form>
  );
};

export default PatientForm;
