import React, { useState, useRef } from 'react';

const BudgetEditor = ({ patient, onSaveBudget }) => {
  const [budget, setBudget] = useState({
    id: Date.now(),
    fecha: new Date().toISOString().split('T')[0],
    pacienteId: patient?.id || '',
    items: [],
    descuento: 0,
    notas: '',
    estado: 'pendiente'
  });

  const [newItem, setNewItem] = useState({
    tratamiento: '',
    cantidad: 1,
    precio: 0,
    diente: ''
  });

  const budgetRef = useRef();

  const handleBudgetChange = (e) => {
    const { name, value } = e.target;
    setBudget(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleItemChange = (e) => {
    const { name, value } = e.target;
    setNewItem(prev => ({
      ...prev,
      [name]: name === 'cantidad' || name === 'precio' ? Number(value) : value
    }));
  };

  const addItem = () => {
    if (!newItem.tratamiento || newItem.precio <= 0) return;
    
    const itemWithId = {
      ...newItem,
      id: Date.now(),
      subtotal: newItem.cantidad * newItem.precio
    };

    setBudget(prev => ({
      ...prev,
      items: [...prev.items, itemWithId]
    }));

    setNewItem({
      tratamiento: '',
      cantidad: 1,
      precio: 0,
      diente: ''
    });
  };

  const removeItem = (id) => {
    setBudget(prev => ({
      ...prev,
      items: prev.items.filter(item => item.id !== id)
    }));
  };

  const calculateTotal = () => {
    const subtotal = budget.items.reduce((sum, item) => sum + item.subtotal, 0);
    const descuento = subtotal * (budget.descuento / 100);
    return {
      subtotal,
      descuento,
      total: subtotal - descuento
    };
  };

  const handlePrint = () => {
    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
      <html>
        <head>
          <title>Presupuesto Dental - ${patient?.nombre || ''}</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            .header { text-align: center; margin-bottom: 20px; }
            .patient-info { margin-bottom: 20px; }
            table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #f2f2f2; }
            .totals { text-align: right; margin-top: 20px; }
            .notes { margin-top: 30px; }
          </style>
        </head>
        <body>
          <div class="header">
            <h2>Presupuesto Dental</h2>
            <p>Fecha: ${new Date(budget.fecha).toLocaleDateString('es-ES')}</p>
          </div>
          <div class="patient-info">
            <p><strong>Paciente:</strong> ${patient?.nombre || ''} ${patient?.apellido || ''}</p>
            <p><strong>Documento:</strong> ${patient?.documento || ''}</p>
          </div>
          <table>
            <thead>
              <tr>
                <th>Tratamiento</th>
                <th>Diente</th>
                <th>Cantidad</th>
                <th>Precio Unitario</th>
                <th>Subtotal</th>
              </tr>
            </thead>
            <tbody>
              ${budget.items.map(item => `
                <tr>
                  <td>${item.tratamiento}</td>
                  <td>${item.diente || '-'}</td>
                  <td>${item.cantidad}</td>
                  <td>$${item.precio.toLocaleString()}</td>
                  <td>$${item.subtotal.toLocaleString()}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
          <div class="totals">
            <p><strong>Subtotal:</strong> $${calculateTotal().subtotal.toLocaleString()}</p>
            <p><strong>Descuento (${budget.descuento}%):</strong> $${calculateTotal().descuento.toLocaleString()}</p>
            <p><strong>Total:</strong> $${calculateTotal().total.toLocaleString()}</p>
          </div>
          ${budget.notas ? `
            <div class="notes">
              <h3>Notas:</h3>
              <p>${budget.notas}</p>
            </div>
          ` : ''}
          <script>
            window.onload = function() {
              setTimeout(function() {
                window.print();
                window.close();
              }, 200);
            };
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  return (
    <div className="bg-white rounded-xl shadow-sm p-6" ref={budgetRef}>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold">Presupuesto Dental</h2>
        <div className="flex space-x-3">
          <button
            onClick={handlePrint}
            className="px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg flex items-center"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" />
            </svg>
            Imprimir
          </button>
          <button
            onClick={() => onSaveBudget(budget)}
            className="px-4 py-2 bg-blue-600 text-white hover:bg-blue-700 rounded-lg"
          >
            Guardar Presupuesto
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Fecha</label>
          <input
            type="date"
            name="fecha"
            value={budget.fecha}
            onChange={handleBudgetChange}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Descuento (%)</label>
          <input
            type="number"
            name="descuento"
            value={budget.descuento}
            onChange={handleBudgetChange}
            min="0"
            max="100"
            className="w-full px-3 py-2 border border-gray-300 rounded-lg"
          />
        </div>
      </div>

      <div className="mb-6">
        <h3 className="text-lg font-medium mb-3">Agregar Tratamiento</h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Tratamiento</label>
            <input
              type="text"
              name="tratamiento"
              value={newItem.tratamiento}
              onChange={handleItemChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg"
              placeholder="Ej: Carilla de porcelana"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Diente</label>
            <input
              type="text"
              name="diente"
              value={newItem.diente}
              onChange={handleItemChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg"
              placeholder="Ej: 11, 12"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Cantidad</label>
            <input
              type="number"
              name="cantidad"
              value={newItem.cantidad}
              onChange={handleItemChange}
              min="1"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Precio</label>
            <input
              type="number"
              name="precio"
              value={newItem.precio}
              onChange={handleItemChange}
              min="0"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg"
            />
          </div>
        </div>
        <button
          onClick={addItem}
          className="mt-3 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
          disabled={!newItem.tratamiento || newItem.precio <= 0}
        >
          Agregar Tratamiento
        </button>
      </div>

      {budget.items.length > 0 && (
        <div className="mb-6">
          <h3 className="text-lg font-medium mb-3">Tratamientos</h3>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tratamiento</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Diente</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Cantidad</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Precio Unitario</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Subtotal</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Acciones</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {budget.items.map(item => (
                  <tr key={item.id}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{item.tratamiento}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{item.diente || '-'}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{item.cantidad}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${item.precio.toLocaleString()}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${item.subtotal.toLocaleString()}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      <button
                        onClick={() => removeItem(item.id)}
                        className="text-red-600 hover:text-red-900"
                      >
                        Eliminar
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <div className="md:col-span-2">
          <label className="block text-sm font-medium text-gray-700 mb-1">Notas</label>
          <textarea
            name="notas"
            value={budget.notas}
            onChange={handleBudgetChange}
            rows="3"
            className="w-full px-3 py-2 border border-gray-300 rounded-lg"
            placeholder="Notas adicionales sobre el presupuesto..."
          />
        </div>
        <div className="bg-gray-50 p-4 rounded-lg">
          <h4 className="text-lg font-medium mb-3">Resumen</h4>
          <div className="space-y-2">
            <div className="flex justify-between">
              <span>Subtotal:</span>
              <span>${calculateTotal().subtotal.toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span>Descuento ({budget.descuento}%):</span>
              <span>-${calculateTotal().descuento.toLocaleString()}</span>
            </div>
            <div className="flex justify-between border-t border-gray-200 pt-2 font-semibold">
              <span>Total:</span>
              <span>${calculateTotal().total.toLocaleString()}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BudgetEditor;