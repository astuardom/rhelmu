import React from 'react';

const LayoutHeader = () => {
  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 py-2 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          {/* Logo Rhelmu optimizado */}
          <div className="h-16 w-auto">
            <img
              src="/logo-rhelmu.png"
              alt="Ortodoncia RHELMÜ"
              className="h-full object-contain"
            />
          </div>
          <h1 className="text-2xl font-semibold text-gray-800"></h1>
        </div>

        <div className="flex items-center space-x-4">
          <div className="text-gray-600 text-sm font-medium">
            Bienvenido 👤
          </div>
          <div className="h-8 w-8 rounded-full bg-gray-200 flex items-center justify-center">
            <span className="text-sm font-medium text-gray-600">DG</span>
          </div>
        </div>
      </div>
    </header>
  );
};

export default LayoutHeader;
