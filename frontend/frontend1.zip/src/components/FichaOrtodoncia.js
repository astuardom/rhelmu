import React, { useState, useEffect } from 'react';

const FichaOrtodoncia = ({ data = {}, onUpdate }) => {
  const [form, setForm] = useState({ maloclusion: '', planTratamiento: '', duracion: '', controles: [] });
  const [selectedControl, setSelectedControl] = useState(null);

  useEffect(() => {
    setForm({
      maloclusion: data.maloclusion || '',
      planTratamiento: data.planTratamiento || '',
      duracion: data.duracion || '',
      controles: data.controles || []
    });
  }, [data]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleAddControl = () => {
    const nuevaFecha = new Date().toLocaleDateString();
    setForm((prev) => ({
      ...prev,
      controles: [...prev.controles, { fecha: nuevaFecha, detalle: '' }]
    }));
  };

  const handleControlChange = (index, value) => {
    const updated = [...form.controles];
    updated[index].detalle = value;
    setForm((prev) => ({ ...prev, controles: updated }));
  };

  const handleDeleteControl = (index) => {
    const updated = [...form.controles];
    updated.splice(index, 1);
    setForm((prev) => ({ ...prev, controles: updated }));
    setSelectedControl(null);
  };

  const handleSave = () => {
    if (onUpdate) {
      onUpdate(form);
      alert('✅ Ficha ortodoncia guardada correctamente');
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow space-y-6">
      <h2 className="text-2xl font-bold">Ficha Ortodoncia</h2>

      <div className="grid grid-cols-1 gap-4">
        <div>
          <label className="block text-sm font-medium">Maloclusión</label>
          <input type="text" name="maloclusion" value={form.maloclusion} onChange={handleChange} className="w-full border rounded px-3 py-1" />
        </div>
        <div>
          <label className="block text-sm font-medium">Plan de Tratamiento</label>
          <input type="text" name="planTratamiento" value={form.planTratamiento} onChange={handleChange} className="w-full border rounded px-3 py-1" />
        </div>
        <div>
          <label className="block text-sm font-medium">Duración</label>
          <input type="text" name="duracion" value={form.duracion} onChange={handleChange} className="w-full border rounded px-3 py-1" />
        </div>
      </div>

      <div>
        <div className="flex justify-between items-center">
          <h3 className="text-lg font-semibold">Controles</h3>
          <button onClick={handleAddControl} className="bg-blue-600 text-white px-3 py-1 rounded hover:bg-blue-700">Agregar control</button>
        </div>

        {form.controles.length === 0 ? (
          <p className="text-gray-500 italic mt-2">No hay controles registrados.</p>
        ) : (
          <table className="w-full mt-4 border">
            <thead>
              <tr className="bg-gray-200 text-left">
                <th className="p-2 border">#</th>
                <th className="p-2 border">Fecha</th>
                <th className="p-2 border">Detalle</th>
                <th className="p-2 border">Acciones</th>
              </tr>
            </thead>
            <tbody>
              {form.controles.map((ctrl, i) => (
                <tr key={i} className="border-t">
                  <td className="p-2 border">{i + 1}</td>
                  <td className="p-2 border">{ctrl.fecha}</td>
                  <td className="p-2 border">
                    <textarea
                      value={ctrl.detalle}
                      onChange={(e) => handleControlChange(i, e.target.value)}
                      className="w-full border rounded px-2 py-1"
                    />
                  </td>
                  <td className="p-2 border">
                    <button onClick={() => handleDeleteControl(i)} className="text-red-600 hover:underline text-sm">Eliminar</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <div className="text-right">
        <button onClick={handleSave} className="bg-green-600 text-white px-5 py-2 rounded hover:bg-green-700">
          Guardar cambios
        </button>
      </div>
    </div>
  );
};

export default FichaOrtodoncia;
