import React, { useState, useEffect } from 'react';
import LayoutHeader from './components/LayoutHeader';
import PatientList from './components/PatientList';
import PatientDetailView from './components/PatientDetailView';
import PatientForm from './components/PatientForm';
import CalendarView from './components/CalendarView';
import AssistantView from './components/AssistantView';
import BudgetView from './components/BudgetView';
import DashboardCard from './components/DashboardCard';
import InventoryManager from './components/InventoryManager';
import ReportsView from './components/ReportsView';
import AuditLog from './components/AuditLog';
import WeeklyAppointments from './components/WeeklyAppointments';

const App = () => {
  const [currentView, setCurrentView] = useState('dashboard');
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [showPatientForm, setShowPatientForm] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [editingPatient, setEditingPatient] = useState(null);

  const [pacientes, setPacientes] = useState([]);
  const [citas, setCitas] = useState([]);
  const [presupuestos, setPresupuestos] = useState([]);
  const [recetas, setRecetas] = useState([]);
  const [userRole, setUserRole] = useState('doctor');

  useEffect(() => {
    fetch("http://localhost:5000/api/pacientes")
      .then(res => res.json())
      .then(data => {
        setPacientes(data);
        if (data.length > 0) setSelectedPatient(data[0]);
      });
  }, []);

  useEffect(() => {
    const editar = (e) => {
      setEditingPatient(e.detail);
      setEditMode(true);
      setShowPatientForm(true);
    };

    const eliminar = (e) => {
      const id = e.detail;
      setPacientes(prev => prev.filter(p => p._id !== id));
      setSelectedPatient(null);
    };

    const actualizar = (e) => {
      const updated = e.detail;
      setPacientes(prev =>
        prev.map(p => (p._id === updated._id ? updated : p))
      );
      setSelectedPatient(updated);
    };

    window.addEventListener("editarPaciente", editar);
    window.addEventListener("eliminarPaciente", eliminar);
    window.addEventListener("actualizarPaciente", actualizar);

    return () => {
      window.removeEventListener("editarPaciente", editar);
      window.removeEventListener("eliminarPaciente", eliminar);
      window.removeEventListener("actualizarPaciente", actualizar);
    };
  }, []);

  useEffect(() => {
    fetch('http://localhost:5000/api/citas')
      .then(res => res.json())
      .then(data => setCitas(data))
      .catch(err => console.error('Error al cargar citas', err));
  }, []);

  useEffect(() => {
    fetch('http://localhost:5000/api/recetas')
      .then(res => res.json())
      .then(data => setRecetas(data))
      .catch(err => console.error('Error al cargar recetas', err));
  }, []);

  return (
    <div className="min-h-screen bg-indigo-50">
      <LayoutHeader />
      <div className="max-w-7xl mx-auto px-4 py-6 grid grid-cols-12 gap-6">
        <div className="col-span-3 space-y-4">
          <div className="bg-white rounded-2xl shadow-md p-5 border border-indigo-100">
            <h2 className="font-bold mb-4 text-indigo-800 uppercase tracking-wide text-sm">Menú Principal</h2>
            <nav className="space-y-2 text-sm">
              <button onClick={() => setCurrentView('dashboard')} className="w-full text-left px-4 py-2 rounded-lg hover:bg-indigo-100 text-indigo-900 font-medium">📊 Dashboard</button>
              <button onClick={() => setCurrentView('pacientes')} className="w-full text-left px-4 py-2 rounded-lg hover:bg-indigo-100 text-indigo-900 font-medium">🧑‍⚕️ Pacientes</button>
              <button onClick={() => setCurrentView('calendario')} className="w-full text-left px-4 py-2 rounded-lg hover:bg-indigo-100 text-indigo-900 font-medium">📅 Calendario</button>
              <button onClick={() => setCurrentView('presupuestos')} className="w-full text-left px-4 py-2 rounded-lg hover:bg-indigo-100 text-indigo-900 font-medium">💰 Presupuestos</button>
              <button onClick={() => setCurrentView('inventario')} className="w-full text-left px-4 py-2 rounded-lg hover:bg-indigo-100 text-indigo-900 font-medium">📦 Inventario</button>
              <button onClick={() => setCurrentView('reportes')} className="w-full text-left px-4 py-2 rounded-lg hover:bg-indigo-100 text-indigo-900 font-medium">📈 Reportes</button>
              <button onClick={() => setCurrentView('configuracion')} className="w-full text-left px-4 py-2 rounded-lg hover:bg-indigo-100 text-indigo-900 font-medium">⚙️ Configuración</button>
              {userRole === 'asistente' && (
                <button onClick={() => setCurrentView('asistente')} className="w-full text-left px-4 py-2 rounded-lg hover:bg-indigo-100 text-indigo-900 font-medium">🧑‍💼 Vista Asistente</button>
              )}
            </nav>
          </div>
        </div>

        <div className="col-span-9 space-y-6">
          {currentView === 'dashboard' && (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <DashboardCard title="Pacientes" value={pacientes.length} color="indigo" trend="+3 hoy" />
                <DashboardCard title="Citas" value={citas.length} color="green" trend="+2 esta semana" />
                <DashboardCard title="Presupuestos" value={presupuestos.length} color="purple" trend="+1 este mes" />
                <DashboardCard title="Recetas" value={recetas.length} color="yellow" trend="+5" />
              </div>
              <WeeklyAppointments citas={citas} pacientes={pacientes} />
            </>
          )}

          {currentView === 'pacientes' && (
            <>
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold text-indigo-800">Pacientes</h2>
                <button onClick={() => { setShowPatientForm(true); setEditMode(false); setEditingPatient(null); }} className="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700">
                  ➕ Agregar Paciente
                </button>
              </div>
              {showPatientForm ? (
                <PatientForm
                  onSave={(savedPatient) => {
                    if (editMode) {
                      setPacientes(prev => prev.map(p => (p._id === savedPatient._id ? savedPatient : p)));
                      alert("✅ Paciente actualizado con éxito");
                    } else {
                      setPacientes(prev => [...prev, savedPatient]);
                      alert("✅ Paciente creado con éxito");
                    }
                    setShowPatientForm(false);
                    setEditMode(false);
                    setEditingPatient(null);
                    setSelectedPatient(savedPatient);
                  }}
                  onCancel={() => setShowPatientForm(false)}
                  patient={editingPatient}
                />
              ) : (
                <>
                  <PatientList patients={pacientes} onSelectPatient={setSelectedPatient} />
                  {selectedPatient && (
                    <PatientDetailView
                      patient={selectedPatient}
                      onUpdateHistorial={(historial) => {
                        setPacientes(prev =>
                          prev.map(p =>
                            p._id === selectedPatient._id ? { ...p, historial } : p
                          )
                        );
                        setSelectedPatient(prev => ({ ...prev, historial }));
                      }}
                    />
                  )}
                </>
              )}
            </>
          )}

{currentView === 'calendario' && (
  <CalendarView
    citas={citas}
    pacientes={pacientes}
    onAddAppointment={(nuevaCita) => {
      if (!nuevaCita.pacienteId || !nuevaCita.fecha || !nuevaCita.hora || !nuevaCita.motivo) {
        alert("⚠️ Todos los campos son obligatorios.");
        return;
      }

      const citaFormateada = {
        ...nuevaCita,
        fecha: nuevaCita.fecha.split('T')[0]  // solo YYYY-MM-DD
      };

      fetch('http://localhost:5000/api/citas', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(citaFormateada)
      })
        .then(res => {
          if (!res.ok) {
            return res.json().then(err => {
              throw new Error(err.error || 'Error al guardar cita');
            });
          }
          return res.json();
        })
        .then(data => {
          setCitas(prev => [...prev, data]);
          alert("✅ Cita guardada con éxito.");
        })
        .catch(err => {
          console.error("❌ Error al guardar cita:", err.message);
          alert("❌ Error al guardar cita: " + err.message);
        });
    }}
    onEditAppointment={(citaActualizada) => {
      fetch(`http://localhost:5000/api/citas/${citaActualizada._id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(citaActualizada)
      })
        .then(res => {
          if (!res.ok) {
            return res.json().then(err => {
              throw new Error(err.error || 'Error al actualizar cita');
            });
          }
          return res.json();
        })
        .then(data => {
          setCitas(prev => prev.map(c => c._id === data._id ? data : c));
          alert("✅ Cita actualizada con éxito.");
        })
        .catch(err => {
          console.error("❌ Error al actualizar cita:", err.message);
          alert("❌ Error al actualizar cita: " + err.message);
        });
    }}
  />
)}


          {currentView === 'presupuestos' && <BudgetView presupuestos={presupuestos} pacientes={pacientes} />}
          {currentView === 'inventario' && <InventoryManager />}
          {currentView === 'reportes' && <ReportsView />}
          {currentView === 'configuracion' && <AuditLog />}
          {currentView === 'asistente' && <AssistantView />}
        </div>
      </div>
    </div>
  );
};

export default App;
