
const initialData = {
  pacientes: [
    {
      id: 1,
      nombre: "María González",
      rut: "12.345.678-9",
      edad: 32,
      genero: "Femenino",
      telefono: "+56955551234",
      email: "maria@example.com",
      fichaOrtodoncia: {
        maloclusion: "Clase II División 1",
        planTratamiento: "Extracción de premolares, uso de brackets autoligables",
        duracion: "24 meses",
        controles: [
          "Control inicial - registro fotográfico",
          "Colocación de brackets",
          "Ajuste de arco mes 3",
          "Evaluación ortopantomografía mes 6"
        ]
      },
      historial: [
        {
          id: 1,
          fecha: "2023-05-15",
          diagnostico: "Maloclusión Clase II",
          tratamiento: "Alineadores transparentes",
          procedimiento: "Colocación de brackets",
          observaciones: "Paciente con hábito de succión digital"
        }
      ],
      fichaClinica: {
        motivoConsulta: "Dientes apiñados",
        historiaMedica: "Sin alergias conocidas",
        habitos: "Bruxismo nocturno",
        examenFacial: "Simétrico",
        examenIntraoral: "Encías inflamadas",
        diagnostico: "Maloclusión Clase II división 1",
        planTratamiento: "Fase 1: Alineación. Fase 2: Corrección mordida"
      },
      odontograma: Array(32).fill().map((_, i) => ({
        numero: i + 1,
        estado: i === 4 || i === 12 ? 'caries' : 'sano',
        tratamiento: i === 4 ? 'Obturación' : '',
        notas: i === 12 ? 'Caries profunda, necesita endodoncia' : ''
      }))
    },
    {
      id: 2,
      nombre: "Carlos Ramírez",
      rut: "22.334.556-1",
      edad: 28,
      genero: "Masculino",
      telefono: "+56987654321",
      email: "carlos@example.com",
      fichaOrtodoncia: {
        maloclusion: "Clase I",
        planTratamiento: "Expansión maxilar y alineadores",
        duracion: "18 meses",
        controles: [
          "Registro inicial",
          "Control mensual",
          "Evaluación de cierre de espacios"
        ]
      },
      historial: [
        {
          id: 2,
          fecha: "2023-04-10",
          diagnostico: "Apiñamiento severo",
          tratamiento: "Expansor palatino",
          procedimiento: "Colocación de disyuntor",
          observaciones: "Control mensual necesario"
        }
      ],
      fichaClinica: {
        motivoConsulta: "Dificultad para masticar",
        historiaMedica: "Asma leve",
        habitos: "Morder lápices",
        examenFacial: "Asimétrico",
        examenIntraoral: "Desgaste en premolares",
        diagnostico: "Clase I con apiñamiento",
        planTratamiento: "Expansión + alineadores"
      },
      odontograma: Array(32).fill().map((_, i) => ({
        numero: i + 1,
        estado: i === 6 ? 'obturado' : 'sano',
        tratamiento: i === 6 ? 'Resina fotopolimerizable' : '',
        notas: i === 6 ? 'Tratamiento exitoso, control semestral' : ''
      }))
    }
  ],
  citas: [
    {
      id: 1,
      pacienteId: 1,
      fecha: "2023-06-20",
      hora: "10:30",
      motivo: "Ajuste de brackets",
      estado: "completada"
    }
  ],
  usuarios: [
    {
      id: 1,
      nombre: "Dr. Pérez",
      rol: "doctor",
      especialidad: "Ortodoncia"
    }
  ],
  metricas: {
    totalPacientes: 124,
    citasEsteMes: 86,
    ingresosMensuales: 12500,
    pacientesNuevos: 18,
    citasPorDia: [12, 15, 8, 10, 14, 9, 11],
    especialidades: [
      { nombre: "Cardiología", cantidad: 32 },
      { nombre: "Pediatría", cantidad: 28 },
      { nombre: "Dermatología", cantidad: 24 },
      { nombre: "Odontología", cantidad: 40 }
    ]
  }
};

export default initialData;
